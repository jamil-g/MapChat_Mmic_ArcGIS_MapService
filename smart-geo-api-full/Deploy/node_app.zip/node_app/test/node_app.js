var express = require("express");
var app = express();

app.get("/node_app/api", function(req, res) {
  console.log("API called");
  res.send("Hello Worlxxxxd!");
});

app.get("/node_app/FeatureServer/0", function(req, res) {
  res.json({ test: "It works", f: req.query.f });
});

// REQUIRED for IISNode to hook into
app.listen(process.env.PORT, () => {
  console.log("listening on", process.env.PORT);
});
